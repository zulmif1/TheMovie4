package id.ac.iainpekalongan.themovie4;

import android.support.v4.app.Fragment;

public class BaseFragment extends Fragment {
    public static final String KEY_MOVIES = "movies";
    public static final String KEY_TV = "tv";

}
